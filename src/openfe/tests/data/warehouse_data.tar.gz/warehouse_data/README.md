# warehouse_data (generated — do not edit)

This directory is unpacked from `../warehouse_data.tar.gz` by the
`warehouse_partial_failure` fixture in `openfe/tests/storage/test_warehouse.py`.
It is git-ignored: changes made here are never committed.

## Updating the data

1. Edit the data and re-create `warehouse_data.tar.gz`.
2. Delete this directory. The fixture only unpacks the tarball when the
   directory is missing, so stale data is otherwise reused silently.
